import React, { PureComponent } from 'react';
import './Transaction.css';
import { Link } from 'react-router-dom';


export default class TransactionRow extends PureComponent {
    render() {

        return (<tr>
            <td>
                <Link to={`/transactions/${this.props.transaction.account}`}>
                    {this.props.transaction.account}    
                </Link>
            </td>
            <td>{this.props.transaction.accountName}</td>
            <td>{this.props.transaction.currencyCode}</td>
            <td>{this.props.transaction.amount}</td>
            <td>{this.props.transaction.transactionType}</td>
        </tr>);
    }
}