import React, { Component } from 'react';
import './Transaction.css';
import { connect } from 'react-redux';
import TransactionRow from './TransactionRow';
import AccountFilters from './filters/AccountFilters';
import TransactionFilters from './filters/TransactionFilters';

class TransactionList extends Component {

    // Returns a function to be passed to Array.filter
    useAccountFilters = (accountFilters) => {
        return (transaction) => {
            return accountFilters[transaction.accountName];
        }
    }

    // Returns a function to be passed to Array.filter
    useTransactionFilters = (transactionFilters) => {
        return (transaction) => {
            return transactionFilters[transaction.transactionType];
        }
    }


    render() {

        const relevantTransactions = this.props.transactions
            .filter(this.useAccountFilters(this.props.accountFilterData))
            .filter(this.useTransactionFilters(this.props.transactionFilterData));

        return (<div className="list-page-layout">
        <div className="all-filter-column">
            <AccountFilters filterDataName={"accountFilterData"}/>
            <TransactionFilters />
        </div>
            <table>
                <thead>
                    <tr>
                        <th>ACCOUNT NO.</th>
                        <th>ACCOUNT NAME</th>
                        <th>CURRENCY</th>
                        <th>AMOUNT</th>
                        <th>TRANSACTION TYPE</th>
                    </tr>
                </thead>
                <tbody>
                    {relevantTransactions.map((transaction) => (<TransactionRow key={transaction.account} transaction={transaction} />))}
                </tbody>
            </table>
        </div>);
    }
}

export default connect(state => state)(TransactionList);