import React, { Component } from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

const GlobalHeader = (props) => ( <div><h1>My Transactions</h1><hr /></div> );

const SingleHeader = (props) => ( <div><h1>Transaction {props.match.params.id}</h1><hr /></div> );

class Header extends Component {
  render() {
    return (
      <div>
        <Router>
            <Switch>
              <Route path="/transactions/:id" component={SingleHeader} />
              <Route path="/transactions" component={GlobalHeader} />
              <Route path="/" component={GlobalHeader} />
            </Switch>
        </Router>

    </div>);
  }
}

export default Header;