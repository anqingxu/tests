import React, { Component } from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import TransactionList from './TransactionList';
import TransactionDetail from './TransactionDetail';
import Header from './Header';

class App extends Component {
  render() {
    return (
      <div className="App">
        <Header />
        <Router>
          <div>
            <Switch>
              <Route path="/transactions/:id" component={TransactionDetail} />
              <Route path="/transactions" component={TransactionList} />
              <Route path="" component={TransactionList} />
            </Switch>
          </div>
        </Router>
      </div>
    );
  }
}

export default App;
