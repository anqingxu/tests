import React, { Component } from 'react';
import './Transaction.css';
import { connect } from 'react-redux';


const mapPropsToState = (state, ownProps) => {
    return {
        transaction: state.transactions.find((tran) => tran.account === ownProps.match.params.id)
    }
}


class TransactionDetail extends Component {

    render() {

        const { transaction } = this.props;

        return (<div className="detail-view">

            <div>
                <span className="header">Account No.:</span>
                <span className="info">{transaction.account}</span>
            </div>

            <div>
                <span className="header">Account Name:</span>
                <span className="info">{transaction.accountName}</span>
            </div>

            <div>
                <span className="header">Currency Code:</span>
                <span className="info">{transaction.currencyCode}</span>
            </div>

            <div>
                <span className="header">Amount:</span>
                <span className="info">{transaction.amount}</span>
            </div>

            <div>
                <span className="header">Transaction Type:</span>
                <span className="info">{transaction.transactionType}</span>
            </div>

        </div>);
    }
}

export default connect(mapPropsToState)(TransactionDetail);