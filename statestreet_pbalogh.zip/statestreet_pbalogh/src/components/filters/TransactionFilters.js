import React, { Component, PureComponent } from 'react';
import './Filters.css';
import { connect } from 'react-redux';
import { TOGGLE_TRANSACTION_FILTER } from '../../actionTypes';


const mapStateToProps = (state) => {
    return {
        filters: state.transactionFilterData
    }
};

const mapDispatchToProps = (dispatch) => ({
    toggleFilter: (filterName) => {
        dispatch({
            type: TOGGLE_TRANSACTION_FILTER,
            payload: filterName
        })
    }
});

class TransactionFilterRow extends PureComponent {

    render() {
        return (<div className="filter-row">
                    <input type="checkbox" checked={this.props.active} onChange={this.props.cl} />
                    <div onClick={this.props.cl} >{this.props.text}</div>
                </div>);
    }
}

class TransactionFilters extends Component {

    onFilterClick = (event, filterName) => {
        event.stopPropagation();
        this.props.toggleFilter(filterName);
    }

    render() {

        return (
            <div className="filter-column">
                <h3>Transaction Type</h3>
                {Object.entries(this.props.filters).map((entry) => <TransactionFilterRow cl={(e) => this.onFilterClick(e, entry[0])} key={entry[0]} text={entry[0]} active={entry[1]} />)}
            </div>
        )
    }
}

export default connect(mapStateToProps, mapDispatchToProps) (TransactionFilters);