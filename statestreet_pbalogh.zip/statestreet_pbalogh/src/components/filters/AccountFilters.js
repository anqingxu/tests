import React, { PureComponent, Component } from 'react';
import './Filters.css';
import { connect } from 'react-redux';
import { TOGGLE_ACCOUNT_FILTER } from '../../actionTypes';

const mapStateToProps = (state) => {
    return {
        filters: state.accountFilterData
    }
};

const mapDispatchToProps = (dispatch) => ({
    toggleFilter: (filterName) => {
        dispatch({
            type: TOGGLE_ACCOUNT_FILTER,
            payload: filterName
        })
    }
});

class AccountFilterRow extends PureComponent {

    render() {
        return (<div className="filter-row">
                    <input type="checkbox" checked={this.props.active} onChange={this.props.cl} />
                    <div onClick={this.props.cl} >{this.props.text}</div>
                </div>);
    }
}

class AccountFilters extends Component {

    onFilterClick = (event, filterName) => {
        event.stopPropagation();
        this.props.toggleFilter(filterName);
    }

    render() {

        return (
            <div className="filter-column">
                <h3>Account Name</h3>
                {Object.entries(this.props.filters).map((entry) => <AccountFilterRow cl={(e) => this.onFilterClick(e, entry[0])} key={entry[0]} text={entry[0]} active={entry[1]} />)}
            </div>
        )
    }
}

export default connect(mapStateToProps, mapDispatchToProps ) (AccountFilters);