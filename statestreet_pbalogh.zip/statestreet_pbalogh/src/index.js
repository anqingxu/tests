import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
//import * as serviceWorker from './serviceWorker';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import rootReducer from './reducers/reducers.js';
import App from './components/App';
import data from './data.json';

import accountFilterData from './accountFilterData';
import transactionFilterData from './transactionFilterData';

const store = createStore(rootReducer, {...data, accountFilterData, transactionFilterData});

ReactDOM.render(<Provider store={store}>
    <App />
  </Provider>, document.getElementById('root'));

