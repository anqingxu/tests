import { combineReducers } from 'redux';
import { TOGGLE_ACCOUNT_FILTER, TOGGLE_TRANSACTION_FILTER } from '../actionTypes';

function accountFilterData(state = {}, action ) {

    switch(action.type) {
        case TOGGLE_ACCOUNT_FILTER:
            const oldValue = state[action.payload];
            var newState = { ...state };
            newState[ action.payload ] = !oldValue;
            return newState;
        default:
            return state;
    }
}

function transactionFilterData(state = {}, action ) {

    switch(action.type) {
        case TOGGLE_TRANSACTION_FILTER:
            const oldValue = state[action.payload];
            var newState = { ...state };
            newState[ action.payload ] = !oldValue;
            return newState;

        default:
            return state;
    }
}

function transactions(state = {}, action ) { return state; }

export default combineReducers({
    accountFilterData,
    transactionFilterData,
    transactions
});