const ACCOUNT_NAMES = { 
    "Auto Loan Account" : true,
    "Checking Account" : true,
    "Credit Card Account" : true,
    "Home Loan Account" : true,
    "Investment Account" : true,
    "Money Market Account" : true,
    "Personal Loan Account" : true,
    "Savings Account" : true, 
};

export default ACCOUNT_NAMES;