const TRANSACTION_FILTERS = { 
    deposit: true,
    invoice: true,
    payment: true,
    withdrawal: true,
};

export default TRANSACTION_FILTERS;
