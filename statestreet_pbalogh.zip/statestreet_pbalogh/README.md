INSTRUCTIONS:

1. cd into the main directory (containing package.json)

2. npm install

3. npm start



There are many improvements remaining to be made. 

- No tests for any components!

- Barely any comments!

- The main content takes a while to load, and this means
  - The data should be paginated and loaded from a remote server, 
  or broken into manageable chunks some other way
  - There should be UI elements to let the user know the progress of data loading and parsing

- String comparisons (e.g., account name in filter vs in data) are case-sensitive

- No error catching (e.g., if router params indicate a transaction that doesn't exist)

- The router doesn't show 404 warnings to users who are requesting unsupported URLs

- The main layout is tabular, so a table is used. 
But performance might be better in some cases with flexbox; worth a try, anyhow.

- Polyfills for older browsers, if any are going to be used on this flexbox-based layout

- Handling edge cases for mobile browsers 

- The filter functions in TransactionList.js are so similar that they could easily be abstracted out 
into a more abstract function. This would allow more *types* of filtering in the future. 

- FEATURE: The column headers should be clickable to allow for sorting of content by type.

